using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectSpawner : MonoBehaviour
{
    [SerializeField] List<GameObject> objectPrefabs;
    [SerializeField] Transform playerTransform;

    [Header("Spawn Variables")]
    [SerializeField] float spawnHeight = 10;
    [SerializeField] float spawnTime = 2f;
    [SerializeField] float spawnRangeX = 5;
    [SerializeField] float minSpacing = 2;
    [SerializeField] float lastSpawnX = 0;
    // Start is called before the first frame update
    void Start()
    {
        SpawnObjects();
    }

    void SpawnObject() {
        float randomX = Random.Range(-spawnRangeX, spawnRangeX);
        Vector3 spawnPos = playerTransform.position + new Vector3(randomX, spawnHeight, 0);
        Instantiate(objectPrefabs[Random.Range(0, objectPrefabs.Count)], spawnPos, Quaternion.identity);
        lastSpawnX = randomX;
    }

    void SpawnObjects() {
        StartCoroutine(SpawnObjectRoutine());
        IEnumerator SpawnObjectRoutine() {
            while(true) {
                yield return new WaitForSeconds(spawnTime);
                SpawnObject();
            }
        }
    }
}
