using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour
{
    [SerializeField] GameObject objectPrefab;
    public int coinCount = 0;
    // Start is called before the first frame update
    void Start()
    {
        ObjectSpeed();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ObjectSpeed() {
        float speedLimit = 5;
        GetComponent<Rigidbody2D>().velocity = new Vector3(0, -speedLimit, 0);
    }

    void OnTriggerEnter2D(Collider2D other) {
        if(other.gameObject.CompareTag("SpaceShip")) {
            Debug.Log("Yay, you collected a coin!");
            Counter.instance.CollectCoin();
            GetComponent<AudioSource>().Play();
            Destroy(this.gameObject);
        }
    }
}
