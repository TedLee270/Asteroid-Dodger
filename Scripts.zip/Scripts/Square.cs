using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Square : MonoBehaviour
{
    [SerializeField] GameObject objectPrefab;
    // Start is called before the first frame update
    void Start()
    {
        ObjectSpeed();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ObjectSpeed() {
        float speedLimit = 5;
        GetComponent<Rigidbody2D>().velocity = new Vector3(0, -speedLimit, 0);
    }

    void OnTriggerEnter2D(Collider2D other) {
        if(other.gameObject.CompareTag("SpaceShip")) {
            Debug.Log("Uh oh, you hit an object!");
            SceneManager.LoadScene("MainMenu");
        }
    }
}
