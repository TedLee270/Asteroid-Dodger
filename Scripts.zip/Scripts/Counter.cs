using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Counter : MonoBehaviour
{
    public static Counter instance;
    [SerializeField] Coin coinCounter;
    [SerializeField] TextMeshProUGUI coinText;
    public int totalCoinsCollected = 0;

    private void Awake()
    {
        // Singleton pattern to ensure only one instance of CoinManager exists
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void CollectCoin()
    {
        totalCoinsCollected++;
        coinText.text = totalCoinsCollected.ToString();
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    }

}
